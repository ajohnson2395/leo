import type { Express, Request, Response, NextFunction } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { 
  insertUserSchema, 
  registerSchema, 
  loginSchema, 
  insertRunningProfileSchema,
  insertMessageSchema,
  chatMessageSchema, 
  RunningProfile,
  Workout,
  TrainingPlan
} from "@shared/schema";
import { getRunningCoachResponse } from "./openai";
import { getDayNames } from "@shared/utils";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import { startMessageScheduler, scheduleUserWorkoutMessages, testScheduleMessagesForUser, scheduleTestMessage } from "./scheduledMessages";
import { ZodError } from "zod";
import { fromZodError } from "zod-validation-error";
import { setupAuth } from "./auth";

// Configure JWT
const JWT_SECRET = process.env.JWT_SECRET || "runcoach_secret_key";
const TOKEN_EXPIRY = "7d";

// Extend the Request interface to include userId
declare global {
  namespace Express {
    interface Request {
      userId?: number;
    }
  }
}

export async function registerRoutes(app: Express): Promise<Server> {
  // Setup authentication (session middleware)
  setupAuth(app);
  
  // JWT helper functions
  const generateToken = (userId: number, email: string): string => {
    return jwt.sign({ id: userId }, JWT_SECRET, { expiresIn: TOKEN_EXPIRY });
  };
  
  // We now use the shared getDayNames() function from @shared/utils
  
  const hashPassword = async (password: string): Promise<string> => {
    const salt = await bcrypt.genSalt(10);
    return bcrypt.hash(password, salt);
  };
  
  const comparePassword = async (password: string, hashedPassword: string): Promise<boolean> => {
    return bcrypt.compare(password, hashedPassword);
  };
  
  // Custom middleware to check authentication and add userId to req object
  const authMiddleware = async (req: Request, res: Response, next: NextFunction) => {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1];
    
    if (!token) {
      return res.status(401).json({ message: "Authentication required" });
    }
    
    try {
      const decoded = jwt.verify(token, JWT_SECRET) as { id: number };
      // Set userId after verifying the token
      if (!decoded || !decoded.id) {
        return res.status(403).json({ message: "Invalid token structure" });
      }
      
      req.userId = decoded.id;
      
      // Fetch the user to get their role
      const user = await storage.getUser(req.userId);
      if (user) {
        req.userRole = user.role;
      }
      
      next();
    } catch (err) {
      return res.status(403).json({ message: "Invalid or expired token" });
    }
  };
  
  // Utility function to ensure userId is a number
  const ensureUserId = (req: Request, res: Response): number | null => {
    const userId = req.userId;
    if (userId === undefined) {
      res.status(401).json({ message: "User ID is missing" });
      return null;
    }
    return userId;
  };
  
  // Admin-only middleware
  const adminMiddleware = (req: Request, res: Response, next: NextFunction) => {
    if (req.userRole !== 'admin') {
      return res.status(403).json({ message: "Admin access required" });
    }
    next();
  };

  // Handle validation errors
  const handleValidationError = (error: any, res: Response) => {
    if (error instanceof ZodError) {
      const validationError = fromZodError(error);
      return res.status(400).json({ message: validationError.message });
    }
    return res.status(400).json({ message: error.message });
  };

  // Register user
  app.post("/api/auth/register", async (req: Request, res: Response) => {
    try {
      const userData = registerSchema.parse(req.body);
      
      // Check if user already exists
      const existingUser = await storage.getUserByEmail(userData.email);
      if (existingUser) {
        return res.status(409).json({ message: "User with this email already exists" });
      }
      
      // Hash password
      const salt = await bcrypt.genSalt(10);
      const hashedPassword = await bcrypt.hash(userData.password, salt);
      
      // Create user without confirmPassword
      const { confirmPassword, ...userDataWithoutConfirm } = userData;
      const user = await storage.createUser({
        ...userDataWithoutConfirm,
        password: hashedPassword
      });
      
      // Generate token
      const token = jwt.sign({ id: user.id }, JWT_SECRET, { expiresIn: TOKEN_EXPIRY });
      
      res.status(201).json({
        token,
        user: {
          id: user.id,
          name: user.name,
          email: user.email,
          role: user.role
        }
      });
    } catch (error) {
      handleValidationError(error, res);
    }
  });

  // Login user
  app.post("/api/auth/login", async (req: Request, res: Response) => {
    try {
      const loginData = loginSchema.parse(req.body);
      
      // Find user
      const user = await storage.getUserByEmail(loginData.email);
      if (!user) {
        return res.status(401).json({ message: "Invalid email or password" });
      }
      
      // Check password
      const isMatch = await bcrypt.compare(loginData.password, user.password);
      if (!isMatch) {
        return res.status(401).json({ message: "Invalid email or password" });
      }
      
      // Generate token
      const token = jwt.sign({ id: user.id }, JWT_SECRET, { expiresIn: TOKEN_EXPIRY });
      
      res.status(200).json({
        token,
        user: {
          id: user.id,
          name: user.name,
          email: user.email,
          role: user.role
        }
      });
    } catch (error) {
      handleValidationError(error, res);
    }
  });

  // Get current user
  app.get("/api/auth/me", authMiddleware, async (req: Request, res: Response) => {
    try {
      const userId = ensureUserId(req, res);
      if (userId === null) return; // Response already sent by ensureUserId
      
      const user = await storage.getUser(userId);
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      res.status(200).json({
        user: {
          id: user.id,
          name: user.name,
          email: user.email,
          role: user.role
        }
      });
    } catch (error) {
      res.status(500).json({ message: "Server error" });
    }
  });

  // Create running profile
  app.post("/api/profile/running", authMiddleware, async (req: Request, res: Response) => {
    try {
      const userId = ensureUserId(req, res);
      if (userId === null) return; // Response already sent by ensureUserId
      
      const profileData = insertRunningProfileSchema.parse({ ...req.body, userId });
      
      // Check if profile already exists
      const existingProfile = await storage.getRunningProfile(userId);
      if (existingProfile) {
        return res.status(409).json({ message: "Running profile already exists" });
      }
      
      const profile = await storage.createRunningProfile(profileData);
      
      // Get user profile for AI welcome message
      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Generate automatic welcome assessment based on profile
      const welcomePrompt = `I just completed my running profile assessment. I'm ${user.name} and I'm a ${profile.experience} runner. My mile time is ${profile.mileTimeMinutes}:${profile.mileTimeSeconds.toString().padStart(2, '0')} and I currently run ${profile.weeklyMileage} miles per week. My training goal is ${profile.trainingGoal}${profile.raceType ? ` and I'm training for a ${profile.raceType}` : ''}. 
      ${profile.strengthTraining ? `For strength training, I prefer ${profile.strengthTraining === 'none' ? 'not to do any' : profile.strengthTraining === 'bodyweight' ? 'bodyweight exercises' : 'weight training'}.` : ''}
      ${profile.preferredRunTime ? `I prefer to run in the ${profile.preferredRunTime}.` : ''}
      ${profile.restDays && profile.restDays.length > 0 ? `My preferred rest days are ${profile.restDays.join(', ')}.` : ''}
      Can you assess my current level and suggest a training approach for me?`;
      
      // Get AI response with assessment
      const aiResponse = await getRunningCoachResponse(
        welcomePrompt,
        userId,
        {
          experience: profile.experience,
          mileTimeMinutes: profile.mileTimeMinutes,
          mileTimeSeconds: profile.mileTimeSeconds,
          weeklyMileage: profile.weeklyMileage,
          trainingGoal: profile.trainingGoal,
          raceType: profile.raceType || undefined,
          strengthTraining: profile.strengthTraining || undefined,
          preferredRunTime: profile.preferredRunTime || undefined,
          restDays: profile.restDays || undefined
        }
      );
      
      // Create system message indicating profile creation
      const systemMessage = await storage.createMessage({
        userId,
        content: `Welcome to RunCoach! I've recorded your running profile details.`,
        isUserMessage: false
      });
      
      // Create AI message with assessment and potential training plan
      const aiMessage = await storage.createMessage({
        userId,
        content: aiResponse.message,
        isUserMessage: false
      });
      
      // If the AI generated workouts, save them
      let workouts: Workout[] = [];
      if (aiResponse.workouts && aiResponse.workouts.length > 0) {
        const workoutsToCreate = aiResponse.workouts.map(workout => ({
          userId,
          title: workout.title,
          description: workout.description,
          dayOfWeek: workout.dayOfWeek,
          intensity: workout.intensity,
          details: workout.details
        }));
        
        workouts = await storage.createManyWorkouts(workoutsToCreate);
      }
      
      // If the AI generated a training plan, save it
      let trainingPlan: TrainingPlan | null = null;
      if (aiResponse.trainingPlan) {
        trainingPlan = await storage.createTrainingPlan({
          userId,
          title: aiResponse.trainingPlan.title,
          description: aiResponse.trainingPlan.description,
          durationWeeks: aiResponse.trainingPlan.durationWeeks,
          currentWeek: 1
        });
      }
      
      // Set up workout reminder messages if the user has a preferred run time
      if (profile.preferredRunTime) {
        // Schedule workout reminders for this user
        await scheduleUserWorkoutMessages(userId);
        console.log(`Scheduled workout reminders for user ${userId} with preferred run time: ${profile.preferredRunTime}`);
      } else {
        console.log(`No workout reminders scheduled for user ${userId} - no preferred run time set`);
      }

      res.status(201).json({ 
        profile,
        initialMessages: [systemMessage, aiMessage],
        workouts,
        trainingPlan
      });
    } catch (error) {
      handleValidationError(error, res);
    }
  });

  // Get running profile
  app.get("/api/profile/running", authMiddleware, async (req: Request, res: Response) => {
    try {
      const userId = ensureUserId(req, res);
      if (userId === null) return; // Response already sent by ensureUserId
      
      const profile = await storage.getRunningProfile(userId);
      
      if (!profile) {
        return res.status(404).json({ message: "Running profile not found" });
      }
      
      res.status(200).json({ profile });
    } catch (error) {
      res.status(500).json({ message: "Server error" });
    }
  });

  // Update running profile
  app.patch("/api/profile/running", authMiddleware, async (req: Request, res: Response) => {
    try {
      const userId = ensureUserId(req, res);
      if (userId === null) return; // Response already sent by ensureUserId
      
      // Allow partial updates
      const updateData = req.body;
      
      const updatedProfile = await storage.updateRunningProfile(userId, updateData);
      
      if (!updatedProfile) {
        return res.status(404).json({ message: "Running profile not found" });
      }
      
      // If preferred run time changed or rest days changed, reschedule messages
      if (updateData.preferredRunTime !== undefined || updateData.restDays !== undefined) {
        // Schedule messages for this user
        await scheduleUserWorkoutMessages(userId);
        console.log(`Rescheduled workout reminders for user ${userId} after profile update`);
      }
      
      res.status(200).json({ profile: updatedProfile });
    } catch (error) {
      handleValidationError(error, res);
    }
  });

  // Get chat messages
  app.get("/api/chat/messages", authMiddleware, async (req: Request, res: Response) => {
    try {
      const userId = ensureUserId(req, res);
      if (userId === null) return; // Response already sent by ensureUserId
      
      const messages = await storage.getMessages(userId);
      
      res.status(200).json({ messages });
    } catch (error) {
      res.status(500).json({ message: "Server error" });
    }
  });
  
  // Endpoint to check if a greeting is needed and generate one if needed
  app.get("/api/chat/greeting", authMiddleware, async (req: Request, res: Response) => {
    try {
      const userId = ensureUserId(req, res);
      if (userId === null) return; // Response already sent by ensureUserId
      
      // Get running profile for context
      const runningProfile = await storage.getRunningProfile(userId);
      
      // Get user information
      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Check if user has any messages (whether a greeting is needed)
      const messages = await storage.getMessages(userId);
      const needsGreeting = messages.length === 0;
      
      // If user has messages, no greeting needed
      if (!needsGreeting) {
        return res.status(200).json({ 
          needsGreeting: false
        });
      }
      
      // Force a greeting to be generated for all users with no messages
      // Even if they've just cleared their messages
      
      // Generate a system message for the greeting
      let systemMessage: string | undefined;
      if (runningProfile) {
        try {
          const userName = user.name;
          
          // Format mile time with leading zeros for seconds
          const formattedSeconds = runningProfile.mileTimeSeconds.toString().padStart(2, '0');
          const experience = runningProfile.experience;
          const mileTime = `${runningProfile.mileTimeMinutes}:${formattedSeconds}`;
          const weeklyMileage = runningProfile.weeklyMileage;
          const trainingGoal = runningProfile.trainingGoal;
          const isRaceTraining = trainingGoal === 'race' ? 'yes' : 'no';
          const raceType = runningProfile.raceType?.replace(/_/g, ' ') || 'race';
          
          systemMessage = `This is a new conversation. You are meeting this user for the first time or they have reset their chat history.

First interaction guidelines:
1. Begin with a warm, enthusiastic greeting using their name (${userName}) exactly ONCE at the start
2. Position yourself as "the world's best running coach" who already understands their running capabilities based on their profile data
3. Briefly acknowledge key profile metrics to demonstrate your understanding (experience: ${experience}, current mile time: ${mileTime}, weekly mileage: ${weeklyMileage})

4. Based on their training goal, respond as follows:
   - If training for a race (${isRaceTraining}): Ask about their goal time for the ${raceType} and mention you'll customize training specifically for that event
   - If general fitness: Ask if they need help being more consistent with their running routine
   - If improving speed: Ask what distances they're most interested in improving their pace for
   - If increasing distance: Ask what their current longest run is and what distance they're aspiring to reach

5. Ask only ONE focused question that feels natural and conversational
6. IMPORTANT: DO NOT create a workout plan or training schedule in this first message - wait for the user to respond to your question first and learn more about their specific needs
7. DO NOT ask about their preferred running time in this first greeting - save that question for a follow-up message
8. Be inquisitive but not overwhelming - you're gathering critical information to serve them better

Remember: You are a world-class coach who balances professional expertise with approachable guidance. Show confidence in your ability to help them reach their goals without being arrogant.`;
        } catch (error) {
          console.error("Error creating system message:", error);
          // Fall back to a simpler system message
          systemMessage = "This is a new conversation. Greet the user warmly as RunCoach AI and ask them about their running goals.";
        }
      }
      
      // Get AI response with a simulated "hi" message
      const aiResponse = await getRunningCoachResponse(
        "Hi, I'd like to start improving my running. Can you help me?",
        userId,
        runningProfile ? {
          experience: runningProfile.experience,
          mileTimeMinutes: runningProfile.mileTimeMinutes,
          mileTimeSeconds: runningProfile.mileTimeSeconds,
          weeklyMileage: runningProfile.weeklyMileage,
          trainingGoal: runningProfile.trainingGoal,
          raceType: runningProfile.raceType || undefined,
          strengthTraining: runningProfile.strengthTraining || undefined,
          preferredRunTime: runningProfile.preferredRunTime || undefined,
          restDays: runningProfile.restDays || undefined
        } : undefined,
        [], // Empty chat history
        systemMessage
      );
      
      // Get today's day name for workout planning
      const { daysOfWeek, today, todayDayName, tomorrowDayName } = getDayNames();
      
      console.log(`DEBUG (greeting): Today is ${todayDayName}, tomorrow is ${tomorrowDayName}`);
    
      // Check if the AI message might include a workout plan
      let messageContainsWorkouts = aiResponse.message.toLowerCase().includes("workout") || 
                                  aiResponse.message.toLowerCase().includes("training") ||
                                  aiResponse.message.toLowerCase().includes("run");
                                  
      // If the greeting message mentions workouts and there are workout objects, ensure message has details
      if (messageContainsWorkouts && aiResponse.workouts && aiResponse.workouts.length > 0) {
        // Check if the AI message doesn't include enough detail
        let messageTooShort = aiResponse.message.length < 300;
        let messageMissingWorkoutDetails = true;
        
        // If this is the first message, we just need to make sure it mentions the first workout
        // Check for presence of workout details
        const detailMarkers = ["warm-up", "cool-down", "minutes", "walking", "jogging", "running"];
        messageMissingWorkoutDetails = !detailMarkers.some(marker => aiResponse.message.toLowerCase().includes(marker));
        
        // If message is too short or missing workout details, augment it
        if (messageTooShort || messageMissingWorkoutDetails) {
          console.log(`Greeting with workout lacks detail (length: ${aiResponse.message.length}), augmenting with first workout data`);
          
          // Find tomorrow's workout or the first one
          const tomorrowWorkout = aiResponse.workouts.find(w => w.dayOfWeek === tomorrowDayName);
          const firstWorkout = tomorrowWorkout || aiResponse.workouts[0];
          
          if (firstWorkout) {
            // Add more detailed description of the workout
            let enhancedMessage = aiResponse.message;
            
            if (!enhancedMessage.includes("Here's your first workout")) {
              enhancedMessage += `\n\nHere's your first workout for ${firstWorkout.dayOfWeek}:\n\n`;
              enhancedMessage += `${firstWorkout.title} - ${firstWorkout.description}\n`;
              enhancedMessage += "This workout includes:\n";
              firstWorkout.details.forEach(detail => {
                enhancedMessage += `- ${detail}\n`;
              });
            }
            
            // Use the enhanced message
            aiResponse.message = enhancedMessage;
            console.log("Greeting message enhanced with workout details");
          }
        }
      }
      
      // Create AI message directly, skip user message
      const aiMessage = await storage.createMessage({
        userId,
        content: aiResponse.message,
        isUserMessage: false
      });
      
      // Consistency check: Ensure the AI message content doesn't mention specific workout days 
      // that aren't actually in the workouts data
      
      // We already defined these variables above, so we don't need to repeat them
      
      // If the AI generated workouts, analyze and save them
      let createdWorkouts: Workout[] = [];
      if (aiResponse.workouts && aiResponse.workouts.length > 0) {
        // Extract days mentioned in created workouts
        const workoutDays = aiResponse.workouts.map(w => w.dayOfWeek);
        console.log(`DEBUG (greeting): Workout days in plan: ${workoutDays.join(', ')}`);
        
        // Check if message mentions tomorrow as a workout day but it's not in the workouts
        const messageContent = aiResponse.message.toLowerCase();
        const mentionsTomorrowWorkout = messageContent.includes(`tomorrow's workout`) || 
                                        messageContent.includes(`tomorrow's run`) || 
                                        messageContent.includes(`${tomorrowDayName.toLowerCase()} workout`) ||
                                        messageContent.includes(`${tomorrowDayName.toLowerCase()} run`);
                                       
        const hasTomorrowWorkout = workoutDays.some(day => day.toLowerCase() === tomorrowDayName.toLowerCase());
        
        if (mentionsTomorrowWorkout && !hasTomorrowWorkout) {
          console.log(`WARNING (greeting): AI message mentions a workout for tomorrow (${tomorrowDayName}) but no such workout exists in the plan`);
          // We'll still process the workouts but this is logged for debugging
        }
        
        // Create the workouts
        const workoutsToCreate = aiResponse.workouts.map(workout => ({
          userId,
          title: workout.title,
          description: workout.description,
          dayOfWeek: workout.dayOfWeek,
          intensity: workout.intensity,
          details: workout.details
        }));
        
        console.log(`Creating/updating ${workoutsToCreate.length} workouts in database from greeting...`);
        createdWorkouts = await storage.createOrUpdateWorkoutsByDay(userId, workoutsToCreate);
        console.log(`Successfully processed ${createdWorkouts.length} workouts from greeting with IDs: ${createdWorkouts.map(w => w.id).join(', ')}`);
        console.log(`Workout days: ${createdWorkouts.map(w => w.dayOfWeek).join(', ')}`);
      }
      
      // If the AI generated a training plan, save it
      let createdTrainingPlan: TrainingPlan | null = null;
      if (aiResponse.trainingPlan) {
        // Check if a plan already exists
        const existingPlan = await storage.getTrainingPlan(userId);
        
        if (!existingPlan) {
          createdTrainingPlan = await storage.createTrainingPlan({
            userId,
            title: aiResponse.trainingPlan.title,
            description: aiResponse.trainingPlan.description,
            durationWeeks: aiResponse.trainingPlan.durationWeeks,
            currentWeek: 1
          });
        } else {
          createdTrainingPlan = existingPlan;
        }
      }
      
      res.status(200).json({ 
        needsGreeting: true,
        greeting: aiMessage,
        workouts: createdWorkouts,
        trainingPlan: createdTrainingPlan
      });
    } catch (error) {
      console.error("Error generating greeting:", error);
      res.status(500).json({ message: "Server error" });
    }
  });

  // Send message to AI coach
  app.post("/api/chat/messages", authMiddleware, async (req: Request, res: Response) => {
    try {
      const userId = ensureUserId(req, res);
      if (userId === null) return; // Response already sent by ensureUserId
      
      const { message } = chatMessageSchema.parse(req.body);
      
      // Create user message
      const userMessage = await storage.createMessage({
        userId,
        content: message,
        isUserMessage: true
      });
      
      // Get running profile for context
      const runningProfile = await storage.getRunningProfile(userId);
      
      // Get chat history
      const chatHistory = await storage.getMessages(userId);
      
      // Check if this is a fresh conversation
      // Either this is the very first message (length = 1) or the user has cleared their history
      // and this is the first new message after clearing (previous messages = 0)
      const previousMessages = chatHistory.length - 1; // Subtract 1 to exclude the message we just created
      const isFreshConversation = previousMessages === 0;
      
      // Prepare system message for fresh conversations
      let systemMessage: string | undefined;
      if (isFreshConversation && runningProfile) {
        try {
          // Get user's name from auth data
          const user = await storage.getUser(userId);
          const userName = user ? user.name : "";
          
          // Format mile time with leading zeros for seconds
          const formattedSeconds = runningProfile.mileTimeSeconds.toString().padStart(2, '0');
          const experience = runningProfile.experience;
          const mileTime = `${runningProfile.mileTimeMinutes}:${formattedSeconds}`;
          const weeklyMileage = runningProfile.weeklyMileage;
          const trainingGoal = runningProfile.trainingGoal;
          const isRaceTraining = trainingGoal === 'race' ? 'yes' : 'no';
          const raceType = runningProfile.raceType?.replace(/_/g, ' ') || 'race';
          
          systemMessage = `This is a new conversation. You are meeting this user for the first time or they have reset their chat history.

First interaction guidelines:
1. Begin with a warm, enthusiastic greeting using their name (${userName}) exactly ONCE at the start
2. Position yourself as "the world's best running coach" who already understands their running capabilities based on their profile data
3. Briefly acknowledge key profile metrics to demonstrate your understanding (experience: ${experience}, current mile time: ${mileTime}, weekly mileage: ${weeklyMileage})

4. Based on their training goal, respond as follows:
   - If training for a race (${isRaceTraining}): Ask about their goal time for the ${raceType} and mention you'll customize training specifically for that event
   - If general fitness: Ask if they need help being more consistent with their running routine
   - If improving speed: Ask what distances they're most interested in improving their pace for
   - If increasing distance: Ask what their current longest run is and what distance they're aspiring to reach

5. Ask only ONE focused question that feels natural and conversational
6. IMPORTANT: DO NOT create a workout plan or training schedule in this first message - wait for the user to respond to your question first and learn more about their specific needs
7. DO NOT ask about their preferred running time in this first greeting - save that question for a follow-up message
8. Be inquisitive but not overwhelming - you're gathering critical information to serve them better

Remember: You are a world-class coach who balances professional expertise with approachable guidance. Show confidence in your ability to help them reach their goals without being arrogant.`;
        } catch (error) {
          console.error("Error creating system message:", error);
          // Fall back to a simpler system message
          systemMessage = "This is a new conversation. Greet the user warmly as RunCoach AI and ask them about their running goals.";
        }
      }
      
      // Get AI response
      const aiResponse = await getRunningCoachResponse(
        message,
        userId,
        runningProfile ? {
          experience: runningProfile.experience,
          mileTimeMinutes: runningProfile.mileTimeMinutes,
          mileTimeSeconds: runningProfile.mileTimeSeconds,
          weeklyMileage: runningProfile.weeklyMileage,
          trainingGoal: runningProfile.trainingGoal,
          raceType: runningProfile.raceType || undefined,
          strengthTraining: runningProfile.strengthTraining || undefined,
          preferredRunTime: runningProfile.preferredRunTime || undefined,
          restDays: runningProfile.restDays || undefined
        } : undefined,
        isFreshConversation ? [] : chatHistory, // If fresh, don't send chat history
        systemMessage
      );
      
      // Check if user requested a workout plan
      const isAskingForPlan = message.toLowerCase().includes("weekly plan") || 
                             message.toLowerCase().includes("plan for the week") || 
                             message.toLowerCase().includes("week plan") ||
                             message.toLowerCase().includes("running plan") ||
                             message.toLowerCase().includes("workout plan");
      
      // If workout plan is requested, make sure response message contains enough details
      if (isAskingForPlan && aiResponse.workouts && aiResponse.workouts.length > 0) {
        // Check if the AI message doesn't include enough detail
        let messageTooShort = aiResponse.message.length < 500;
        let messageMissingDays = true;
        
        // Check if message includes days
        const dayNames = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
        let daysFound = 0;
        
        dayNames.forEach(day => {
          if (aiResponse.message.includes(day + ":")) daysFound++;
        });
        
        // If we find most of the days in the format "Day:" then it likely has detail
        messageMissingDays = daysFound < 4;
        
        // If message is too short or missing days, expand it
        if (messageTooShort || messageMissingDays) {
          console.log(`Workout plan response lacks detail (${daysFound} days found, length ${aiResponse.message.length}), augmenting with workout data`);
          
          // Build a more detailed response that includes all workouts
          let detailedPlan = aiResponse.message;
          
          // Only add this separator if the message doesn't already end with similar formatting
          if (!detailedPlan.includes("complete week") && !detailedPlan.includes("weekly schedule")) {
            detailedPlan += "\n\nHere's your complete weekly schedule:\n\n";
          }
          
          aiResponse.workouts.forEach(workout => {
            // Only add workout details if they're not already included
            if (!detailedPlan.includes(`${workout.dayOfWeek}:`)) {
              detailedPlan += `${workout.dayOfWeek}: ${workout.title} - ${workout.description}\n`;
              detailedPlan += "Details:\n";
              workout.details.forEach(detail => {
                detailedPlan += `- ${detail}\n`;
              });
              detailedPlan += "\n";
            }
          });
          
          // Use the expanded message
          aiResponse.message = detailedPlan;
          
          console.log("Message enhanced with full workout details");
        }
      }
      
      // Create AI message with safety check for content
      const aiMessage = await storage.createMessage({
        userId,
        content: aiResponse.message || "Sorry, your previous message didn't come through. Would you mind resending?",
        isUserMessage: false
      });
      
      // Consistency check: Ensure the AI message content doesn't mention specific workout days 
      // that aren't actually in the workouts data
      
      // Get today's day name
      const { daysOfWeek, today, todayDayName, tomorrowDayName } = getDayNames();
      
      console.log(`DEBUG: Today is ${todayDayName}, tomorrow is ${tomorrowDayName}`);
      
      // If the AI generated workouts, analyze and save them
      let createdWorkouts: Workout[] = [];
      if (aiResponse.workouts && aiResponse.workouts.length > 0) {
        // Extract days mentioned in created workouts
        const workoutDays = aiResponse.workouts.map(w => w.dayOfWeek);
        console.log(`DEBUG: Workout days in plan: ${workoutDays.join(', ')}`);
        
        // Check if message mentions tomorrow as a workout day but it's not in the workouts
        const messageContent = (aiResponse.message || "").toLowerCase();
        const mentionsTomorrowWorkout = messageContent.includes(`tomorrow's workout`) || 
                                       messageContent.includes(`tomorrow's run`) || 
                                       messageContent.includes(`${tomorrowDayName.toLowerCase()} workout`) ||
                                       messageContent.includes(`${tomorrowDayName.toLowerCase()} run`);
                                       
        const hasTomorrowWorkout = workoutDays.some(day => day.toLowerCase() === tomorrowDayName.toLowerCase());
        
        if (mentionsTomorrowWorkout && !hasTomorrowWorkout) {
          console.log(`WARNING: AI message mentions a workout for tomorrow (${tomorrowDayName}) but no such workout exists in the plan`);
          // We'll still process the workouts but this is logged for debugging
        }
        
        // Create the workouts
        const workoutsToCreate = aiResponse.workouts.map(workout => ({
          userId,
          title: workout.title,
          description: workout.description,
          dayOfWeek: workout.dayOfWeek,
          intensity: workout.intensity,
          details: workout.details
        }));
        
        console.log(`Creating/updating ${workoutsToCreate.length} workouts in database from chat message...`);
        createdWorkouts = await storage.createOrUpdateWorkoutsByDay(userId, workoutsToCreate);
        console.log(`Successfully processed ${createdWorkouts.length} workouts with IDs: ${createdWorkouts.map(w => w.id).join(', ')}`);
        console.log(`Workout days: ${createdWorkouts.map(w => w.dayOfWeek).join(', ')}`);
      }
      
      // If the AI generated a training plan, save it
      let createdTrainingPlan: TrainingPlan | null = null;
      if (aiResponse.trainingPlan) {
        // Check if a plan already exists
        const existingPlan = await storage.getTrainingPlan(userId);
        
        if (!existingPlan) {
          createdTrainingPlan = await storage.createTrainingPlan({
            userId,
            title: aiResponse.trainingPlan.title,
            description: aiResponse.trainingPlan.description,
            durationWeeks: aiResponse.trainingPlan.durationWeeks,
            currentWeek: 1
          });
        } else {
          createdTrainingPlan = existingPlan;
        }
      }
      
      res.status(201).json({
        userMessage,
        aiMessage,
        workouts: createdWorkouts,
        trainingPlan: createdTrainingPlan || aiResponse.trainingPlan
      });
    } catch (error) {
      console.error("Error in chat:", error);
      handleValidationError(error, res);
    }
  });

  // Get workouts
  app.get("/api/workouts", authMiddleware, async (req: Request, res: Response) => {
    try {
      const userId = ensureUserId(req, res);
      if (userId === null) return; // Response already sent by ensureUserId
      
      const workouts = await storage.getWorkouts(userId);
      console.log(`GET /api/workouts: Found ${workouts.length} workouts for user ${userId}`);
      if (workouts.length > 0) {
        console.log(`Workout days: ${workouts.map(w => w.dayOfWeek).join(', ')}`);
        console.log(`Workout IDs: ${workouts.map(w => w.id).join(', ')}`);
      }
      
      res.status(200).json({ workouts });
    } catch (error) {
      console.error("Error fetching workouts:", error);
      res.status(500).json({ message: "Server error" });
    }
  });

  // Update workout completion
  app.patch("/api/workouts/:id/complete", authMiddleware, async (req: Request, res: Response) => {
    try {
      const userId = ensureUserId(req, res);
      if (userId === null) return; // Response already sent by ensureUserId
      
      const workoutId = parseInt(req.params.id);
      const { isComplete } = req.body;
      
      if (typeof isComplete !== 'boolean') {
        return res.status(400).json({ message: "isComplete must be a boolean value" });
      }
      
      // Get the workout to verify ownership
      const workout = await storage.getWorkout(workoutId);
      
      if (!workout) {
        return res.status(404).json({ message: "Workout not found" });
      }
      
      if (workout.userId !== userId) {
        return res.status(403).json({ message: "Not authorized to update this workout" });
      }
      
      const updatedWorkout = await storage.updateWorkoutCompletion(workoutId, isComplete);
      
      res.status(200).json({ workout: updatedWorkout });
    } catch (error) {
      res.status(500).json({ message: "Server error" });
    }
  });

  // Get training plan
  app.get("/api/training-plan", authMiddleware, async (req: Request, res: Response) => {
    try {
      const userId = ensureUserId(req, res);
      if (userId === null) return; // Response already sent by ensureUserId
      
      const trainingPlan = await storage.getTrainingPlan(userId);
      
      if (!trainingPlan) {
        return res.status(404).json({ message: "Training plan not found" });
      }
      
      res.status(200).json({ trainingPlan });
    } catch (error) {
      res.status(500).json({ message: "Server error" });
    }
  });

  // Update training plan week
  app.patch("/api/training-plan/:id/week", authMiddleware, async (req: Request, res: Response) => {
    try {
      const userId = ensureUserId(req, res);
      if (userId === null) return; // Response already sent by ensureUserId
      
      const planId = parseInt(req.params.id);
      const { week } = req.body;
      
      if (typeof week !== 'number' || week < 1) {
        return res.status(400).json({ message: "Week must be a positive number" });
      }
      
      // Get the plan to verify ownership
      const plan = await storage.getTrainingPlan(userId);
      
      if (!plan) {
        return res.status(404).json({ message: "Training plan not found" });
      }
      
      if (plan.id !== planId) {
        return res.status(403).json({ message: "Not authorized to update this plan" });
      }
      
      const updatedPlan = await storage.updateTrainingPlanWeek(planId, week);
      
      res.status(200).json({ trainingPlan: updatedPlan });
    } catch (error) {
      res.status(500).json({ message: "Server error" });
    }
  });

  // ADMIN API ROUTES
  
  // Delete all messages for a user
  app.delete("/api/admin/messages", authMiddleware, adminMiddleware, async (req: Request, res: Response) => {
    try {
      const userId = ensureUserId(req, res);
      if (userId === null) return; // Response already sent by ensureUserId
      
      // Clear all messages for this user
      const deletedCount = await storage.clearMessages(userId);
      
      // Get user for token regeneration
      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Generate a fresh token to ensure continued authentication
      const token = generateToken(userId, user.email);
      
      res.status(200).json({ 
        success: true, 
        message: `Deleted ${deletedCount} messages`,
        token: token
      });
    } catch (error) {
      console.error("Error clearing messages:", error);
      res.status(500).json({ message: "Server error" });
    }
  });
  
  // Delete all workouts for a user
  app.delete("/api/admin/workouts", authMiddleware, adminMiddleware, async (req: Request, res: Response) => {
    try {
      const userId = ensureUserId(req, res);
      if (userId === null) return; // Response already sent by ensureUserId
      
      // Clear all workouts for this user
      const deletedCount = await storage.clearWorkouts(userId);
      
      // Get user for token regeneration
      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Generate a fresh token to ensure continued authentication
      const token = generateToken(userId, user.email);
      
      res.status(200).json({ 
        success: true, 
        message: `Deleted ${deletedCount} workouts`,
        token: token
      });
    } catch (error) {
      console.error("Error clearing workouts:", error);
      res.status(500).json({ message: "Server error" });
    }
  });
  
  // Delete training plan for a user
  app.delete("/api/admin/training-plan", authMiddleware, adminMiddleware, async (req: Request, res: Response) => {
    try {
      const userId = ensureUserId(req, res);
      if (userId === null) return; // Response already sent by ensureUserId
      
      // Clear the training plan for this user
      const success = await storage.clearTrainingPlan(userId);
      
      // Get user for token regeneration
      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Generate a fresh token to ensure continued authentication
      const token = generateToken(userId, user.email);
      
      res.status(200).json({ 
        success, 
        message: success ? "Training plan deleted" : "No training plan found",
        token: token
      });
    } catch (error) {
      console.error("Error clearing training plan:", error);
      res.status(500).json({ message: "Server error" });
    }
  });
  
  // Delete all user data (messages, workouts, training plan)
  app.delete("/api/admin/all", authMiddleware, adminMiddleware, async (req: Request, res: Response) => {
    try {
      const userId = ensureUserId(req, res);
      if (userId === null) return; // Response already sent by ensureUserId
      
      // Clear all data for this user
      const messageCount = await storage.clearMessages(userId);
      const workoutCount = await storage.clearWorkouts(userId);
      const planDeleted = await storage.clearTrainingPlan(userId);
      
      // Get user for token regeneration
      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Generate a fresh token to ensure continued authentication
      const token = generateToken(userId, user.email);
      
      res.status(200).json({ 
        success: true, 
        message: `Deleted ${messageCount} messages, ${workoutCount} workouts, and ${planDeleted ? 1 : 0} training plan`,
        token: token
      });
    } catch (error) {
      console.error("Error clearing all data:", error);
      res.status(500).json({ message: "Server error" });
    }
  });
  
  // Get all users (admin only)
  app.get("/api/admin/users", authMiddleware, adminMiddleware, async (req: Request, res: Response) => {
    try {
      const users = await storage.getAllUsers();
      
      // For security, remove password hashes before sending to client
      const sanitizedUsers = users.map(user => {
        const { password, ...userWithoutPassword } = user;
        return userWithoutPassword;
      });
      
      res.status(200).json({ users: sanitizedUsers });
    } catch (error) {
      console.error("Error fetching users:", error);
      res.status(500).json({ message: "Server error" });
    }
  });
  
  // Update user role (admin only)
  app.patch("/api/admin/users/:id/role", authMiddleware, adminMiddleware, async (req: Request, res: Response) => {
    try {
      const userId = parseInt(req.params.id);
      const { role } = req.body;
      
      if (!userId || isNaN(userId)) {
        return res.status(400).json({ message: "Invalid user ID" });
      }
      
      if (!role || (role !== "admin" && role !== "user")) {
        return res.status(400).json({ message: "Invalid role. Must be 'admin' or 'user'" });
      }
      
      // Get the user to update
      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Update the user role
      const updatedUser = await storage.updateUserRole(userId, role);
      if (!updatedUser) {
        return res.status(500).json({ message: "Failed to update user role" });
      }
      
      // For security, remove password hash before sending to client
      const { password, ...userWithoutPassword } = updatedUser;
      
      res.status(200).json({ 
        success: true, 
        user: userWithoutPassword
      });
    } catch (error) {
      console.error("Error updating user role:", error);
      res.status(500).json({ message: "Failed to update user role" });
    }
  });

  // Create scheduled message system
  console.log("Starting workout reminder scheduler...");
  startMessageScheduler();
  
  // Schedule messages for existing users
  setTimeout(async () => {
    console.log("Scheduling workout reminders for existing users...");
    const users = await storage.getAllUsers();
    for (const user of users) {
      await scheduleUserWorkoutMessages(user.id);
    }
    console.log(`Scheduled workout reminders for ${users.length} users`);
  }, 5000); // Wait 5 seconds after server start to schedule messages
  
  // Add endpoint to test workout reminders
  app.post("/api/test/workout-reminder", authMiddleware, async (req: Request, res: Response) => {
    try {
      const userId = ensureUserId(req, res);
      if (userId === null) return;
      
      // Get user's workouts
      const workouts = await storage.getWorkouts(userId);
      if (workouts.length === 0) {
        return res.status(400).json({ 
          message: "You have no workouts. Create workouts before testing the reminder system."
        });
      }
      
      // Use scheduleTestMessage for immediate testing
      await scheduleTestMessage(userId);
      
      res.status(200).json({ 
        message: "Test workout reminder scheduled. You should receive a message in approximately 1 minute."
      });
    } catch (error) {
      console.error("Error scheduling test reminder:", error);
      res.status(500).json({ message: "Server error" });
    }
  });
  
  // Mobile App Push Notification Registration Endpoint
  app.post("/api/notifications/register", authMiddleware, async (req: Request, res: Response) => {
    try {
      const userId = ensureUserId(req, res);
      if (userId === null) return;
      
      const { pushToken } = req.body;
      
      if (!pushToken) {
        return res.status(400).json({ message: "Push token is required" });
      }
      
      // Store the push token in the user's profile
      const updatedUser = await storage.updateUserPushToken(userId, pushToken);
      
      if (!updatedUser) {
        return res.status(404).json({ message: "User not found" });
      }
      
      console.log(`Registered push token for user ${userId}`);
      res.status(200).json({ message: "Push token registered successfully" });
    } catch (error) {
      console.error("Error registering push token:", error);
      res.status(500).json({ message: "Server error" });
    }
  });
  
  const httpServer = createServer(app);
  return httpServer;
}
