import { drizzle } from "drizzle-orm/neon-serverless";
import { neon } from "@neondatabase/serverless";
import * as schema from "@shared/schema";

// Log to ensure the DATABASE_URL is set
console.log('Database URL exists:', !!process.env.DATABASE_URL);

// Create the Neon SQL client 
const sql = neon(process.env.DATABASE_URL!);

// Create the Drizzle ORM client
export const db = drizzle(sql);

// Export the sql client for use with session store
export const client = sql;