import { storage } from './storage';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

// Get directory name for ES modules
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Define paths for persistence files
const PERSISTENCE_DIR = path.join(__dirname, 'data', 'persistence');
const USERS_FILE = path.join(PERSISTENCE_DIR, 'users.json');

async function migrateUserRoles() {
  try {
    console.log('Starting user role migration...');
    
    // Check if users file exists
    if (!fs.existsSync(USERS_FILE)) {
      console.log('No users file found. Nothing to migrate.');
      return;
    }
    
    // Load the current users
    const usersData = JSON.parse(fs.readFileSync(USERS_FILE, 'utf8'));
    
    // Check if users need migration (missing role field)
    const needsMigration = usersData.some((user: any) => !user.role);
    
    if (!needsMigration) {
      console.log('Users already have role field. No migration needed.');
      return;
    }
    
    // Update users with role
    const updatedUsers = usersData.map((user: any) => {
      // Set the first user as admin, others as regular users
      const role = user.id === 1 ? 'admin' : 'user';
      return { ...user, role };
    });
    
    // Save the updated users back to the file
    fs.writeFileSync(USERS_FILE, JSON.stringify(updatedUsers, null, 2));
    
    console.log(`Migration complete. Updated ${updatedUsers.length} users.`);
    console.log('User ID 1 set as admin, all others set as regular users.');
    
  } catch (error) {
    console.error('Error during user role migration:', error);
  }
}

export { migrateUserRoles };