import { 
  User, InsertUser, 
  RunningProfile, InsertRunningProfile,
  Message, InsertMessage,
  Workout, InsertWorkout,
  TrainingPlan, InsertTrainingPlan
} from "@shared/schema";
import { createSessionStorage } from "./session";
import { Store } from "express-session";
import fs from "fs";
import path from "path";
import { fileURLToPath } from 'url';

// Get directory name for ES modules
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Define paths for persistence files
const DATA_DIR = path.join(__dirname, 'data');
const PERSISTENCE_DIR = path.join(DATA_DIR, 'persistence');

// Create directories if they don't exist
if (!fs.existsSync(DATA_DIR)) {
  console.log('Creating data directory:', DATA_DIR);
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

if (!fs.existsSync(PERSISTENCE_DIR)) {
  console.log('Creating persistence directory:', PERSISTENCE_DIR);
  fs.mkdirSync(PERSISTENCE_DIR, { recursive: true });
}

const USERS_FILE = path.join(PERSISTENCE_DIR, 'users.json');
const PROFILES_FILE = path.join(PERSISTENCE_DIR, 'profiles.json');
const MESSAGES_FILE = path.join(PERSISTENCE_DIR, 'messages.json');
const WORKOUTS_FILE = path.join(PERSISTENCE_DIR, 'workouts.json');
const PLANS_FILE = path.join(PERSISTENCE_DIR, 'plans.json');
const COUNTERS_FILE = path.join(PERSISTENCE_DIR, 'counters.json');

export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  getAllUsers(): Promise<User[]>;
  updateUserRole(userId: number, role: string): Promise<User | undefined>;
  updateUserPushToken(userId: number, pushToken: string): Promise<User | undefined>;

  // Running Profile operations
  getRunningProfile(userId: number): Promise<RunningProfile | undefined>;
  createRunningProfile(profile: InsertRunningProfile): Promise<RunningProfile>;
  updateRunningProfile(userId: number, profile: Partial<InsertRunningProfile>): Promise<RunningProfile | undefined>;

  // Message operations
  getMessages(userId: number): Promise<Message[]>;
  createMessage(message: InsertMessage): Promise<Message>;

  // Workout operations
  getWorkouts(userId: number): Promise<Workout[]>;
  getWorkout(id: number): Promise<Workout | undefined>;
  getWorkoutByDay(userId: number, dayOfWeek: string): Promise<Workout | undefined>;
  createWorkout(workout: InsertWorkout): Promise<Workout>;
  updateWorkoutCompletion(id: number, isComplete: boolean): Promise<Workout | undefined>;
  updateWorkout(id: number, updateData: Partial<InsertWorkout>): Promise<Workout | undefined>;
  createManyWorkouts(workouts: InsertWorkout[]): Promise<Workout[]>;
  createOrUpdateWorkoutsByDay(userId: number, workouts: InsertWorkout[]): Promise<Workout[]>;

  // Training Plan operations
  getTrainingPlan(userId: number): Promise<TrainingPlan | undefined>;
  createTrainingPlan(plan: InsertTrainingPlan): Promise<TrainingPlan>;
  updateTrainingPlanWeek(id: number, week: number): Promise<TrainingPlan | undefined>;
  
  // Admin operations
  clearMessages(userId: number): Promise<number>;
  clearWorkouts(userId: number): Promise<number>;
  clearTrainingPlan(userId: number): Promise<boolean>;
  
  // Session store
  sessionStore: Store;
}

// In-memory storage implementation
export class MemStorage implements IStorage {
  private users: User[] = [];
  private runningProfiles: RunningProfile[] = [];
  private messages: Message[] = [];
  private workouts: Workout[] = [];
  private trainingPlans: TrainingPlan[] = [];
  private userIdCounter = 1;
  private profileIdCounter = 1;
  private messageIdCounter = 1;
  private workoutIdCounter = 1;
  private planIdCounter = 1;
  sessionStore: Store;

  constructor() {
    // Use memory-based session storage
    this.sessionStore = createSessionStorage();
    
    // Load data from persistence files if they exist
    this.loadFromFiles();
  }
  
  // Helper method to save all data to files
  private saveToFiles() {
    try {
      // Ensure the directory exists
      if (!fs.existsSync(PERSISTENCE_DIR)) {
        fs.mkdirSync(PERSISTENCE_DIR, { recursive: true });
      }
      
      // Save users
      fs.writeFileSync(USERS_FILE, JSON.stringify(this.users, (key, value) => {
        // Convert dates to ISO strings for JSON serialization
        if (value instanceof Date) {
          return value.toISOString();
        }
        return value;
      }, 2));
      
      // Save profiles
      fs.writeFileSync(PROFILES_FILE, JSON.stringify(this.runningProfiles, (key, value) => {
        if (value instanceof Date) {
          return value.toISOString();
        }
        return value;
      }, 2));
      
      // Save messages
      fs.writeFileSync(MESSAGES_FILE, JSON.stringify(this.messages, (key, value) => {
        if (value instanceof Date) {
          return value.toISOString();
        }
        return value;
      }, 2));
      
      // Save workouts
      fs.writeFileSync(WORKOUTS_FILE, JSON.stringify(this.workouts, (key, value) => {
        if (value instanceof Date) {
          return value.toISOString();
        }
        return value;
      }, 2));
      
      // Save training plans
      fs.writeFileSync(PLANS_FILE, JSON.stringify(this.trainingPlans, (key, value) => {
        if (value instanceof Date) {
          return value.toISOString();
        }
        return value;
      }, 2));
      
      // Save counters
      fs.writeFileSync(COUNTERS_FILE, JSON.stringify({
        userIdCounter: this.userIdCounter,
        profileIdCounter: this.profileIdCounter,
        messageIdCounter: this.messageIdCounter,
        workoutIdCounter: this.workoutIdCounter,
        planIdCounter: this.planIdCounter
      }, null, 2));
      
      console.log('Data saved to persistence files');
    } catch (error) {
      console.error('Error saving data to files:', error);
    }
  }
  
  // Helper method to load all data from files
  private loadFromFiles() {
    try {
      // Load users if file exists
      if (fs.existsSync(USERS_FILE)) {
        const usersData = JSON.parse(fs.readFileSync(USERS_FILE, 'utf8'));
        this.users = usersData.map((user: any) => ({
          ...user,
          createdAt: new Date(user.createdAt)
        }));
        console.log(`Loaded ${this.users.length} users from storage`);
      }
      
      // Load profiles if file exists
      if (fs.existsSync(PROFILES_FILE)) {
        const profilesData = JSON.parse(fs.readFileSync(PROFILES_FILE, 'utf8'));
        this.runningProfiles = profilesData.map((profile: any) => ({
          ...profile,
          createdAt: new Date(profile.createdAt)
        }));
        console.log(`Loaded ${this.runningProfiles.length} profiles from storage`);
      }
      
      // Load messages if file exists
      if (fs.existsSync(MESSAGES_FILE)) {
        const messagesData = JSON.parse(fs.readFileSync(MESSAGES_FILE, 'utf8'));
        this.messages = messagesData.map((message: any) => ({
          ...message,
          createdAt: new Date(message.createdAt)
        }));
        console.log(`Loaded ${this.messages.length} messages from storage`);
      }
      
      // Load workouts if file exists
      if (fs.existsSync(WORKOUTS_FILE)) {
        const workoutsData = JSON.parse(fs.readFileSync(WORKOUTS_FILE, 'utf8'));
        this.workouts = workoutsData.map((workout: any) => ({
          ...workout,
          createdAt: new Date(workout.createdAt)
        }));
        console.log(`Loaded ${this.workouts.length} workouts from storage`);
      }
      
      // Load training plans if file exists
      if (fs.existsSync(PLANS_FILE)) {
        const plansData = JSON.parse(fs.readFileSync(PLANS_FILE, 'utf8'));
        this.trainingPlans = plansData.map((plan: any) => ({
          ...plan,
          createdAt: new Date(plan.createdAt)
        }));
        console.log(`Loaded ${this.trainingPlans.length} training plans from storage`);
      }
      
      // Load counters if file exists
      if (fs.existsSync(COUNTERS_FILE)) {
        const counters = JSON.parse(fs.readFileSync(COUNTERS_FILE, 'utf8'));
        this.userIdCounter = counters.userIdCounter || 1;
        this.profileIdCounter = counters.profileIdCounter || 1;
        this.messageIdCounter = counters.messageIdCounter || 1;
        this.workoutIdCounter = counters.workoutIdCounter || 1;
        this.planIdCounter = counters.planIdCounter || 1;
        console.log('Loaded counter values from storage');
      }
    } catch (error) {
      console.error('Error loading data from files:', error);
      // If there's an error loading, we'll use default empty arrays
    }
  }

  // User operations
  async getUser(id: number): Promise<User | undefined> {
    return this.users.find(user => user.id === id);
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    return this.users.find(user => user.email === email);
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const now = new Date();
    const user: User = {
      id: this.userIdCounter++,
      ...insertUser,
      // Ensure role defaults to "user" if not specified
      role: insertUser.role || "user",
      pushToken: null, // Initialize with null
      createdAt: now
    };
    this.users.push(user);
    this.saveToFiles(); // Save to files after modification
    return user;
  }
  
  async getAllUsers(): Promise<User[]> {
    return [...this.users];
  }
  
  async updateUserRole(userId: number, role: string): Promise<User | undefined> {
    const userIndex = this.users.findIndex(user => user.id === userId);
    
    if (userIndex === -1) {
      return undefined;
    }
    
    // Update the user's role
    const updatedUser = {
      ...this.users[userIndex],
      role
    };
    
    this.users[userIndex] = updatedUser;
    this.saveToFiles(); // Save to files after modification
    return updatedUser;
  }
  
  async updateUserPushToken(userId: number, pushToken: string): Promise<User | undefined> {
    const userIndex = this.users.findIndex(user => user.id === userId);
    
    if (userIndex === -1) {
      return undefined;
    }
    
    // Update the user's push token
    const updatedUser = {
      ...this.users[userIndex],
      pushToken
    };
    
    this.users[userIndex] = updatedUser;
    this.saveToFiles(); // Save to files after modification
    return updatedUser;
  }

  // Running Profile operations
  async getRunningProfile(userId: number): Promise<RunningProfile | undefined> {
    return this.runningProfiles.find(profile => profile.userId === userId);
  }

  async createRunningProfile(insertProfile: InsertRunningProfile): Promise<RunningProfile> {
    const now = new Date();
    const profile: RunningProfile = {
      id: this.profileIdCounter++,
      ...insertProfile,
      raceType: insertProfile.raceType ?? null, // Ensure raceType is string or null, not undefined
      strengthTraining: insertProfile.strengthTraining ?? null, // Ensure strengthTraining is string or null
      preferredRunTime: insertProfile.preferredRunTime ?? null, // Ensure preferredRunTime is string or null
      restDays: insertProfile.restDays ?? null, // Ensure restDays is string[] or null
      createdAt: now
    };
    this.runningProfiles.push(profile);
    this.saveToFiles(); // Save to files after modification
    return profile;
  }

  async updateRunningProfile(userId: number, updateData: Partial<InsertRunningProfile>): Promise<RunningProfile | undefined> {
    const profileIndex = this.runningProfiles.findIndex(profile => profile.userId === userId);
    
    if (profileIndex === -1) {
      return undefined;
    }
    
    // Process fields to handle null/undefined correctly
    const processedData = {
      ...updateData,
      raceType: updateData.raceType ?? null,
      strengthTraining: updateData.strengthTraining ?? null,
      preferredRunTime: updateData.preferredRunTime ?? null,
      restDays: updateData.restDays ?? null
    };
    
    const updatedProfile = {
      ...this.runningProfiles[profileIndex],
      ...processedData
    };
    
    this.runningProfiles[profileIndex] = updatedProfile;
    this.saveToFiles(); // Save to files after modification
    return updatedProfile;
  }

  // Message operations
  async getMessages(userId: number): Promise<Message[]> {
    return this.messages
      .filter(message => message.userId === userId)
      .sort((a, b) => {
        // Handle null dates (shouldn't happen in practice but TypeScript needs the check)
        const aTime = a.createdAt?.getTime() ?? 0;
        const bTime = b.createdAt?.getTime() ?? 0;
        return aTime - bTime;
      });
  }

  async createMessage(insertMessage: InsertMessage): Promise<Message> {
    const now = new Date();
    const message: Message = {
      id: this.messageIdCounter++,
      ...insertMessage,
      createdAt: now
    };
    this.messages.push(message);
    this.saveToFiles(); // Save to files after modification
    return message;
  }

  // Workout operations
  async getWorkouts(userId: number): Promise<Workout[]> {
    return this.workouts
      .filter(workout => workout.userId === userId)
      .sort((a, b) => {
        const dayOrder: Record<string, number> = {
          'Monday': 1,
          'Tuesday': 2,
          'Wednesday': 3,
          'Thursday': 4,
          'Friday': 5,
          'Saturday': 6,
          'Sunday': 7
        };
        // Get day values with fallback to avoid TypeScript error
        const dayA = dayOrder[a.dayOfWeek] || 0; 
        const dayB = dayOrder[b.dayOfWeek] || 0;
        return dayA - dayB;
      });
  }

  async getWorkout(id: number): Promise<Workout | undefined> {
    return this.workouts.find(workout => workout.id === id);
  }
  
  async getWorkoutByDay(userId: number, dayOfWeek: string): Promise<Workout | undefined> {
    const userWorkouts = this.workouts.filter(workout => 
      workout.userId === userId && 
      workout.dayOfWeek.toLowerCase() === dayOfWeek.toLowerCase()
    );
    
    // Return the most recently created workout for that day if multiple exist
    if (userWorkouts.length > 0) {
      return userWorkouts.sort((a, b) => {
        // Sort by creation date (newest first)
        const aTime = a.createdAt?.getTime() ?? 0;
        const bTime = b.createdAt?.getTime() ?? 0;
        return bTime - aTime;
      })[0];
    }
    
    return undefined;
  }

  async createWorkout(insertWorkout: InsertWorkout): Promise<Workout> {
    const now = new Date();
    
    // Ensure details is an array of strings
    let details: string[] = [];
    if (Array.isArray(insertWorkout.details)) {
      details = insertWorkout.details.map(item => String(item));
    }
    
    const workout: Workout = {
      id: this.workoutIdCounter++,
      userId: insertWorkout.userId,
      title: insertWorkout.title,
      description: insertWorkout.description,
      dayOfWeek: insertWorkout.dayOfWeek,
      intensity: insertWorkout.intensity,
      details: details,
      isComplete: false,
      createdAt: now
    };
    
    this.workouts.push(workout);
    this.saveToFiles(); // Save to files after modification
    return workout;
  }

  async updateWorkoutCompletion(id: number, isComplete: boolean): Promise<Workout | undefined> {
    const workoutIndex = this.workouts.findIndex(workout => workout.id === id);
    
    if (workoutIndex === -1) {
      return undefined;
    }
    
    const updatedWorkout = {
      ...this.workouts[workoutIndex],
      isComplete
    };
    
    this.workouts[workoutIndex] = updatedWorkout;
    this.saveToFiles(); // Save to files after modification
    return updatedWorkout;
  }
  
  async updateWorkout(id: number, updateData: Partial<InsertWorkout>): Promise<Workout | undefined> {
    const workoutIndex = this.workouts.findIndex(workout => workout.id === id);
    
    if (workoutIndex === -1) {
      return undefined;
    }
    
    // Ensure details is an array of strings if provided
    let details: string[] | undefined = undefined;
    if (updateData.details) {
      details = Array.isArray(updateData.details) 
        ? updateData.details.map(item => String(item))
        : updateData.details;
    }
    
    const updatedWorkout = {
      ...this.workouts[workoutIndex],
      ...updateData,
      details: details || this.workouts[workoutIndex].details
    };
    
    this.workouts[workoutIndex] = updatedWorkout;
    this.saveToFiles(); // Save to files after modification
    return updatedWorkout;
  }

  async createManyWorkouts(insertWorkouts: InsertWorkout[]): Promise<Workout[]> {
    const workouts: Workout[] = [];
    for (const insertWorkout of insertWorkouts) {
      const workout = await this.createWorkout(insertWorkout);
      workouts.push(workout);
    }
    return workouts;
  }
  
  async createOrUpdateWorkoutsByDay(userId: number, insertWorkouts: InsertWorkout[]): Promise<Workout[]> {
    const results: Workout[] = [];
    
    for (const insertWorkout of insertWorkouts) {
      // Check if a workout already exists for this day
      const existingWorkout = await this.getWorkoutByDay(userId, insertWorkout.dayOfWeek);
      
      if (existingWorkout) {
        // Update the existing workout and preserve completion status
        const isComplete = existingWorkout.isComplete;
        const updated = await this.updateWorkout(existingWorkout.id, {
          ...insertWorkout,
          isComplete
        });
        
        if (updated) {
          console.log(`Updated existing workout for ${insertWorkout.dayOfWeek} (ID: ${existingWorkout.id})`);
          results.push(updated);
        }
      } else {
        // Create a new workout
        const workout = await this.createWorkout(insertWorkout);
        console.log(`Created new workout for ${insertWorkout.dayOfWeek} (ID: ${workout.id})`);
        results.push(workout);
      }
    }
    
    return results;
  }

  // Training Plan operations
  async getTrainingPlan(userId: number): Promise<TrainingPlan | undefined> {
    // Get most recent plan
    return this.trainingPlans
      .filter(plan => plan.userId === userId)
      .sort((a, b) => {
        // Handle null dates (shouldn't happen in practice but TypeScript needs the check)
        const aTime = a.createdAt?.getTime() ?? 0;
        const bTime = b.createdAt?.getTime() ?? 0;
        return bTime - aTime;
      })[0];
  }

  async createTrainingPlan(insertPlan: InsertTrainingPlan): Promise<TrainingPlan> {
    const now = new Date();
    const plan: TrainingPlan = {
      id: this.planIdCounter++,
      ...insertPlan,
      currentWeek: 1,
      createdAt: now
    };
    this.trainingPlans.push(plan);
    this.saveToFiles(); // Save to files after modification
    return plan;
  }

  async updateTrainingPlanWeek(id: number, week: number): Promise<TrainingPlan | undefined> {
    const planIndex = this.trainingPlans.findIndex(plan => plan.id === id);
    
    if (planIndex === -1) {
      return undefined;
    }
    
    const updatedPlan = {
      ...this.trainingPlans[planIndex],
      currentWeek: week
    };
    
    this.trainingPlans[planIndex] = updatedPlan;
    this.saveToFiles(); // Save to files after modification
    return updatedPlan;
  }

  // Admin operations
  async clearMessages(userId: number): Promise<number> {
    const initialCount = this.messages.length;
    this.messages = this.messages.filter(message => message.userId !== userId);
    const deletedCount = initialCount - this.messages.length;
    this.saveToFiles(); // Save to files after modification
    return deletedCount;
  }

  async clearWorkouts(userId: number): Promise<number> {
    const initialCount = this.workouts.length;
    this.workouts = this.workouts.filter(workout => workout.userId !== userId);
    const deletedCount = initialCount - this.workouts.length;
    this.saveToFiles(); // Save to files after modification
    return deletedCount;
  }

  async clearTrainingPlan(userId: number): Promise<boolean> {
    const initialCount = this.trainingPlans.length;
    this.trainingPlans = this.trainingPlans.filter(plan => plan.userId !== userId);
    const deleted = initialCount > this.trainingPlans.length;
    this.saveToFiles(); // Save to files after modification
    return deleted;
  }
}

// Export an instance of the in-memory storage
export const storage = new MemStorage();