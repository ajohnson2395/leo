import { Express, Request, Response, NextFunction } from 'express';
import session from 'express-session';
import { createSessionStorage } from './session';
import jwt from 'jsonwebtoken';
import bcrypt from 'bcryptjs';

// JWT Secret for token signing
const JWT_SECRET = process.env.JWT_SECRET || 'default-secret-key';

// Interface for JWT Payload
interface JwtPayload {
  id: number;
}

export function setupAuth(app: Express) {
  // Set up session middleware with memory store
  const sessionStore = createSessionStorage();
  
  app.use(
    session({
      secret: process.env.JWT_SECRET || 'session-secret',
      resave: false,
      saveUninitialized: false,
      cookie: {
        secure: process.env.NODE_ENV === 'production',
        maxAge: 24 * 60 * 60 * 1000, // 24 hours
      },
      store: sessionStore,
    })
  );

  // We're not returning anything from setupAuth anymore
  // The session middleware is registered above
}

// Extend Request to include userId and userRole
declare global {
  namespace Express {
    interface Request {
      userId?: number;
      userRole?: string;
    }
  }
}