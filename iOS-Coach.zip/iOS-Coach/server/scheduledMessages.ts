import { storage } from './storage';
import { RunningProfile, Workout } from '@shared/schema';
import { getRunningCoachResponse } from './openai';
import cron from 'node-cron';
import { getDayNames } from '@shared/utils';

interface ScheduledMessage {
  userId: number;
  scheduledTime: Date;
  workoutId: number;
  minutesBefore: number;
  sent: boolean;
}

// In-memory storage for scheduled messages
const scheduledMessages: ScheduledMessage[] = [];

// Function to generate a random number of minutes (5-10)
function getRandomMinutesBefore(): number {
  return Math.floor(Math.random() * 6) + 5; // Random int from 5 to 10
}

// Convert time string (e.g., "6:45 am") to minutes since midnight
function timeStringToMinutes(timeString: string): number {
  // Safety check for null or undefined
  if (!timeString) {
    console.log('Warning: Received null or undefined time string');
    return 8 * 60; // Default to 8:00 AM (480 minutes)
  }
  
  // Handle categorical time preferences like "morning", "mid_day", "evening"
  if (timeString === 'morning') {
    return 6 * 60 + 30; // 6:30 AM
  } else if (timeString === 'mid_day') {
    return 12 * 60; // 12:00 PM
  } else if (timeString === 'evening') {
    return 18 * 60; // 6:00 PM
  }
  
  // Try to parse an actual time string format like "6:45 am"
  try {
    const [time, period] = timeString.split(' ');
    const [hourStr, minuteStr] = time.split(':');
    
    let hour = parseInt(hourStr);
    const minute = parseInt(minuteStr);
    
    // Convert to 24-hour format
    if (period.toLowerCase() === 'pm' && hour < 12) {
      hour += 12;
    } else if (period.toLowerCase() === 'am' && hour === 12) {
      hour = 0;
    }
    
    return hour * 60 + minute;
  } catch (error) {
    console.log(`Warning: Could not parse time string "${timeString}", using default`);
    return 8 * 60; // Default to 8:00 AM if parsing fails
  }
}

// Format time for cron expression (returns "30 6 * * *" for 6:30 AM)
function formatTimeForCron(hour: number, minute: number): string {
  return `${minute} ${hour} * * *`;
}

// Create a coach message for the upcoming workout
async function createWorkoutReminderMessage(userId: number, workoutId: number, minutesBefore: number): Promise<string> {
  const workout = await storage.getWorkout(workoutId);
  if (!workout) {
    return "It's almost time for your workout, but I couldn't find the details. Please check the app for your scheduled activity.";
  }
  
  // Create a science-backed encouragement message
  const encouragements = [
    "Exercise releases endorphins that boost your mood and energy levels, making you feel great after your workout.",
    "Regular physical activity has been shown to improve cognitive function and creative thinking throughout the day.",
    "Studies show that morning workouts help establish consistency and can improve your sleep quality tonight.",
    "Research indicates that regular running increases the production of brain-derived neurotrophic factor (BDNF), which enhances brain health.",
    "Your cardiovascular system becomes more efficient with each workout, making everyday activities easier.",
    "Exercise has been proven to reduce levels of cortisol, the body's stress hormone, helping you feel more relaxed today.",
    "Working out increases oxygen flow throughout your body, improving mental clarity and focus for hours afterward.",
    "Today's workout will strengthen your heart muscle, making it more efficient at pumping blood with each beat.",
    "Studies show that regular exercise increases mitochondrial function, giving you more energy throughout your day.",
    "Each workout contributes to improved insulin sensitivity, helping your body manage blood sugar more effectively.",
    "The positive metabolic effects of today's workout will continue for hours after you finish."
  ];
  
  const randomEncouragement = encouragements[Math.floor(Math.random() * encouragements.length)];
  
  return `Good morning! Almost time for your ${workout.title} workout. Hope you're getting ready and warmed up for your run.
  
Here's a quick reminder of what's planned:
${workout.description}

${randomEncouragement}

Is there anything you'd like to adjust about today's plan?`;
}

// Schedule a check-in message for a specific workout
async function scheduleWorkoutMessage(userId: number, workout: Workout, preferredTime: string): Promise<void> {
  try {
    // Parse the preferred time
    const preferredMinutes = timeStringToMinutes(preferredTime);
    
    // Get today's day using the shared function
    const { todayDayName } = getDayNames();
    
    // Only schedule if this workout matches today's day
    if (workout.dayOfWeek.toLowerCase() !== todayDayName.toLowerCase()) {
      return;
    }
    
    // Generate random minutes before
    const minutesBefore = getRandomMinutesBefore();
    
    // Calculate the reminder time
    const reminderMinutes = preferredMinutes - minutesBefore;
    const reminderHour = Math.floor(reminderMinutes / 60);
    const reminderMinute = reminderMinutes % 60;
    
    // Schedule the message
    const scheduledTime = new Date();
    scheduledTime.setHours(reminderHour, reminderMinute, 0, 0);
    
    // If the time has already passed today, don't schedule
    if (scheduledTime <= new Date()) {
      console.log(`Skipping reminder for workout ${workout.id} as the time has passed`);
      return;
    }
    
    scheduledMessages.push({
      userId,
      workoutId: workout.id,
      scheduledTime,
      minutesBefore,
      sent: false
    });
    
    console.log(`Scheduled reminder for workout ${workout.id} at ${scheduledTime.toLocaleTimeString()}, ${minutesBefore} minutes before ${preferredTime}`);
  } catch (error) {
    console.error(`Error scheduling message for workout ${workout.id}:`, error);
  }
}

// Schedule check-in messages for all of a user's workouts
export async function scheduleUserWorkoutMessages(userId: number): Promise<void> {
  try {
    // Get the user's profile to find their preferred workout time
    const profile = await storage.getRunningProfile(userId);
    if (!profile || !profile.preferredRunTime) {
      console.log(`User ${userId} has no profile or preferred run time`);
      return;
    }
    
    // Get all workouts for the user
    const workouts = await storage.getWorkouts(userId);
    if (workouts.length === 0) {
      console.log(`User ${userId} has no workouts`);
      return;
    }
    
    // Schedule messages for each workout
    for (const workout of workouts) {
      await scheduleWorkoutMessage(userId, workout, profile.preferredRunTime);
    }
  } catch (error) {
    console.error(`Error scheduling messages for user ${userId}:`, error);
  }
}

// Process scheduled messages periodically
export function startMessageScheduler(): void {
  // Check for messages to send every minute
  setInterval(async () => {
    const now = new Date();
    
    for (const message of scheduledMessages) {
      if (!message.sent && message.scheduledTime <= now) {
        try {
          // Get the user to check if they exist
          const user = await storage.getUser(message.userId);
          if (!user) {
            console.log(`User ${message.userId} not found, skipping reminder`);
            message.sent = true; // Mark as processed anyway
            continue;
          }
          
          // Get the workout details
          const workout = await storage.getWorkout(message.workoutId);
          if (!workout) {
            console.log(`Workout ${message.workoutId} not found, skipping reminder`);
            message.sent = true; // Mark as processed anyway
            continue;
          }
          
          // Create the message content
          const content = await createWorkoutReminderMessage(
            message.userId, 
            message.workoutId, 
            message.minutesBefore
          );
          
          // Create the AI message
          await storage.createMessage({
            userId: message.userId,
            content,
            isUserMessage: false
          });
          
          // If user has a push token, try to send a push notification
          if (user.pushToken) {
            try {
              // This is where we would integrate with a push notification service
              // In a real-world implementation, you would use FCM, APNS, or Expo's push service
              console.log(`PUSH NOTIFICATION to token ${user.pushToken}: Workout reminder - ${workout.title} in ${message.minutesBefore} minutes`);
              
              // Example of notification payload structure for future implementation
              const notificationPayload = {
                to: user.pushToken,
                title: `Workout Reminder: ${workout.title}`,
                body: `Your ${workout.title} workout starts in ${message.minutesBefore} minutes.`,
                data: {
                  workoutId: workout.id,
                  type: 'workout_reminder'
                },
              };
              
              // You would send this payload to your push notification service
              // await sendPushNotification(notificationPayload);
              
            } catch (pushError) {
              console.error(`Failed to send push notification to user ${user.id}:`, pushError);
              // Continue even if push notification fails
            }
          }
          
          // Mark as sent
          message.sent = true;
          console.log(`Sent workout reminder to user ${message.userId} for workout ${message.workoutId}`);
        } catch (error) {
          console.error(`Error sending scheduled message to user ${message.userId}:`, error);
        }
      }
    }
    
    // Clean up sent messages that are older than a day
    const yesterday = new Date(now.getTime() - 24 * 60 * 60 * 1000);
    const messagesToRemove = scheduledMessages.filter(m => m.sent && m.scheduledTime < yesterday);
    messagesToRemove.forEach(m => {
      const index = scheduledMessages.indexOf(m);
      if (index !== -1) {
        scheduledMessages.splice(index, 1);
      }
    });
  }, 60000); // Check every minute
  
  // Schedule messages at midnight every day
  cron.schedule('0 0 * * *', async () => {
    console.log('Running daily message scheduler...');
    
    // Get all users
    const users = await storage.getAllUsers();
    
    // Schedule messages for each user
    for (const user of users) {
      await scheduleUserWorkoutMessages(user.id);
    }
    
    console.log('Daily message scheduling complete');
  });
}

// Function to manually trigger scheduling for testing
export async function testScheduleMessagesForUser(userId: number): Promise<void> {
  await scheduleUserWorkoutMessages(userId);
}

// For immediate testing, schedule a message to be sent soon
export async function scheduleTestMessage(userId: number): Promise<void> {
  try {
    // Get the user to check if they exist and have a push token
    const user = await storage.getUser(userId);
    if (!user) {
      console.log(`User ${userId} not found, cannot schedule test message`);
      return;
    }
    
    // Get user's workouts
    const workouts = await storage.getWorkouts(userId);
    if (workouts.length === 0) {
      console.log(`User ${userId} has no workouts for test scheduling`);
      return;
    }
    
    // Use the first workout for testing
    const testWorkout = workouts[0];
    
    // Schedule test message for 30 seconds from now for immediate testing
    const testTime = new Date();
    testTime.setSeconds(testTime.getSeconds() + 30);
    
    scheduledMessages.push({
      userId,
      workoutId: testWorkout.id,
      scheduledTime: testTime,
      minutesBefore: 5, // Simulate 5 minutes before
      sent: false
    });
    
    // Log different message based on push token availability
    if (user.pushToken) {
      console.log(`Test message with push notification scheduled for user ${userId}, workout ${testWorkout.id} at ${testTime.toLocaleTimeString()}`);
    } else {
      console.log(`Test message scheduled for user ${userId}, workout ${testWorkout.id} at ${testTime.toLocaleTimeString()} (no push token available)`);
    }
  } catch (error) {
    console.error(`Error scheduling test message for user ${userId}:`, error);
  }
}