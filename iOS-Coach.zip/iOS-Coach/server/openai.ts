import OpenAI from "openai";
import { ChatCompletionMessageParam } from "openai/resources/chat/completions";
import fs from "fs";
import path from "path";
import { fileURLToPath } from 'url';

// the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

// Get directory name for ES modules
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Define coaching preferences type
interface CoachingPreferences {
  coaching_styles: {
    motivational: string;
    technical: string;
    supportive: string;
    detailed: string;
    encouraging: string;
    prescriptive: string;
    conversational: string;
  };
  question_preferences: {
    specificity: string;
    guidance: string;
    name_usage: string;
    specific: string;
    fitness_focus: string;
    follow_up_questions?: string;
  };
  workout_suggestions: {
    approach: string;
    scheduling: string;
    consistency?: string;
    timing: string;
    duration: string;
    presentation: string;
    strength_training: string;
  };
  feedback_notes?: Array<{
    timestamp: string;
    user_id: number;
    user_name: string;
    rating?: number;
    feedback: string;
  }>;
}

// Load coaching preferences from JSON file
const coachingPreferencesPath = path.join(__dirname, 'data', 'coachingPreferences.json');
let coachingPreferences: CoachingPreferences;

try {
  // Check if the directory exists, create it if not
  const dataDir = path.join(__dirname, 'data');
  if (!fs.existsSync(dataDir)) {
    console.log('Creating data directory:', dataDir);
    fs.mkdirSync(dataDir, { recursive: true });
  }

  // Try to read the coaching preferences file
  if (fs.existsSync(coachingPreferencesPath)) {
    coachingPreferences = JSON.parse(fs.readFileSync(coachingPreferencesPath, 'utf-8'));
    console.log('Successfully loaded coaching preferences from:', coachingPreferencesPath);
  } else {
    // Use default coaching preferences if file doesn't exist
    console.log('Coaching preferences file not found. Using default preferences.');
    coachingPreferences = {
      "coaching_styles": {
        "motivational": "more",
        "technical": "balanced",
        "supportive": "more",
        "detailed": "more",
        "encouraging": "more",
        "prescriptive": "more",
        "conversational": "more"
      },
      "question_preferences": {
        "specificity": "more",
        "guidance": "Ask specific questions about running goals and preferences. Provide prescriptive recommendations rather than open-ended questions. Focus on running performance metrics like pace, distance, and training frequency.",
        "name_usage": "In the very first message, use the user's name once for a personalized greeting. After that, minimize using the user's name and prefer pronouns like 'you' instead.",
        "specific": "Focus on running preferences, running-specific fitness goals, and running improvement metrics",
        "fitness_focus": "ONLY ask running-specific questions related to running goals, preferences, and progress. Ask about feelings ONLY in the direct context of run preparation or recovery. NEVER ask general questions like 'How are you feeling today?' or 'How's your day going?' Instead, ask targeted questions about specific running parameters, nutrition for runners, or recovery metrics.",
        "follow_up_questions": "After your first greeting message and the user's response, ask follow-up questions about specific running times and about training preferences. Ask at most 2 questions per message."
      },
      "workout_suggestions": {
        "approach": "Make specific recommendations with running workouts as the primary focus, complemented by strength, mobility and cross-training exercises that will improve running performance",
        "scheduling": "Wait until after the user's second message before creating any workout plans. For new users, ask questions first to understand their needs before creating a schedule.",
        "consistency": "MAINTAIN CONSISTENCY between your chat messages and the workouts you create.",
        "timing": "For running workouts, ask about preferred running time in a follow-up message, not in your first greeting message.",
        "duration": "For beginners, start with 20-30 minute runs with walk breaks. For intermediate, 30-45 minute steady runs. For advanced, 45-60+ minute structured runs with varying intensities.",
        "presentation": "When creating a full week of workouts, include all details directly in the chat message.",
        "strength_training": "When recommending bodyweight or strength exercises, ALWAYS be extremely specific with exact reps, sets, and rest periods."
      }
    };
    
    // Write the default preferences to file for future use
    fs.writeFileSync(coachingPreferencesPath, JSON.stringify(coachingPreferences, null, 2));
    console.log('Created default coaching preferences file at:', coachingPreferencesPath);
  }
} catch (error) {
  console.error('Error with coaching preferences file:', error);
  // Fallback to minimal default preferences if there's an error
  coachingPreferences = {
    coaching_styles: { 
      motivational: "more",
      technical: "balanced",
      supportive: "more",
      detailed: "more",
      encouraging: "more",
      prescriptive: "more",
      conversational: "more"
    },
    question_preferences: { 
      specificity: "more",
      guidance: "Ask specific questions about running goals.",
      name_usage: "Use 'you' instead of the user's name.",
      specific: "Focus on running metrics.",
      fitness_focus: "Focus only on running-related questions."
    },
    workout_suggestions: { 
      approach: "Make specific recommendations.",
      scheduling: "Wait until understanding user needs.",
      timing: "Ask about preferred time.",
      duration: "Adjust based on experience.",
      presentation: "Include details in chat.",
      strength_training: "Be specific with exercises."
    }
  };
}

export interface RunningCoachResponse {
  message: string;
  workouts?: {
    title: string;
    description: string;
    dayOfWeek: string;
    intensity: string;
    details: string[];
  }[];
  trainingPlan?: {
    title: string;
    description: string;
    durationWeeks: number;
  };
}

export async function getRunningCoachResponse(
  userMessage: string,
  userId: number | null,
  runningProfile?: {
    experience: string;
    mileTimeMinutes: number;
    mileTimeSeconds: number;
    weeklyMileage: number;
    trainingGoal: string;
    raceType?: string;
    strengthTraining?: string;
    preferredRunTime?: string;
    restDays?: string[];
  },
  chatHistory?: { content: string; isUserMessage: boolean }[],
  systemMessage?: string
): Promise<RunningCoachResponse> {
  // Safely handle null userId
  const safeUserId = userId ?? 0; // Fallback to 0 for error cases
  try {
    // Extract coaching preferences
    const { coaching_styles, question_preferences, workout_suggestions } = coachingPreferences;

    // Formulate the system prompt with running profile information and coaching preferences
    let systemPrompt = `You are RunCoach AI, a professional running coach specialized in providing personalized training advice to runners.
Your coaching style is:
- Motivational: ${coaching_styles.motivational}
- Technical: ${coaching_styles.technical}
- Supportive: ${coaching_styles.supportive}
- Detailed: ${coaching_styles.detailed}
- Encouraging: ${coaching_styles.encouraging}
- Prescriptive: ${coaching_styles.prescriptive}
- Conversational: ${coaching_styles.conversational}

Important guidelines:
- ${question_preferences.name_usage}
- ${question_preferences.guidance}
- ${question_preferences.fitness_focus}
- ${question_preferences.follow_up_questions}
- Limit questions to 1-2 per message
- Focus all workouts and advice on improving running performance
- For your first response to a new user, make it warm, welcoming, and motivational - mention you see their profile data and are excited to help them reach their goals. Keep this first message concise and focused on asking questions to understand their needs. DO NOT create workout plans or schedules in your first or second message - wait until you have gathered enough information from the user. Only ask the most important question for getting started. In onboarding, always ask which day the user prefers for their long run - this is critical for building their training plan.

For workout scheduling:
- ${workout_suggestions.approach}
- ${workout_suggestions.scheduling}
- ${workout_suggestions.timing}
- ${workout_suggestions.duration}
- ${workout_suggestions.presentation}
- ${workout_suggestions.strength_training}`;

    if (runningProfile) {
      const { 
        experience, 
        mileTimeMinutes, 
        mileTimeSeconds, 
        weeklyMileage, 
        trainingGoal, 
        raceType, 
        strengthTraining, 
        preferredRunTime, 
        restDays 
      } = runningProfile;
      
      systemPrompt += `\n\nRunner profile:
- Experience level: ${experience}
- Current mile time: ${mileTimeMinutes}:${mileTimeSeconds.toString().padStart(2, '0')}
- Weekly mileage: ${weeklyMileage} miles
- Training goal: ${trainingGoal}${raceType ? `\n- Race type: ${raceType}` : ''}${strengthTraining ? `\n- Strength training preference: ${strengthTraining}` : ''}${preferredRunTime ? `\n- Preferred running time: ${preferredRunTime}` : ''}${restDays && restDays.length > 0 ? `\n- Rest days: ${restDays.join(', ')}` : ''}`;
    }

    systemPrompt += `\n\nWhen asked about creating training plans, provide structured workout information and interpret the request as the user wanting you to create a plan for them. Return your response in JSON format with the following structure:
{
  "message": "Your conversational response to the user",
  "workouts": [
    {
      "title": "Workout title (e.g., 'Monday: Interval Training')",
      "description": "Brief workout description",
      "dayOfWeek": "Day of the week",
      "intensity": "High, Medium, or Low",
      "details": ["Step 1 of workout", "Step 2 of workout", "etc."]
    }
  ],
  "trainingPlan": {
    "title": "Plan title (e.g., '10K Speed Improvement Plan')",
    "description": "Brief plan description",
    "durationWeeks": number of weeks for the plan
  }
}

Important guidelines for creating plans:
1. CRITICAL: MAINTAIN PERFECT CONSISTENCY between your chat messages and the workouts you create. If you mention a specific workout in your chat message (e.g., "tomorrow is a rest day" or "your next run is on Wednesday"), make sure that EXACTLY matches the actual workout data you send in the "workouts" field. Do not mention upcoming workouts unless they match what's in the plan. When a user tweaks or modifies just one workout on a specific day, ONLY list the details for the changed day - do not repeat the entire week.
2. EXACT DAY MAPPING: Always include ACCURATE DAY REFERENCES in your messages. For example, if today is ${new Date().toLocaleDateString('en-US', { weekday: 'long' })}, refer to tomorrow as ${new Date(Date.now() + 86400000).toLocaleDateString('en-US', { weekday: 'long' })}. Use these proper day names in both your message and the workout data. The "dayOfWeek" field in each workout MUST use the correct capitalized day name (Monday, Tuesday, etc.). CRITICALLY IMPORTANT: Always start your training plans from TOMORROW, not from Monday. Create workouts that the user can start right away tomorrow, with a clear plan for the next 7 days. If the user specifically asks to start today, include a workout for today as well.
3. DYNAMIC PROGRESSIVE TRAINING: Create varied and dynamic training plans that evolve week-to-week. Even when the general workout types remain the same day-to-day (e.g., Tuesday is always intervals), the specific details MUST change each week. For example, Week 1 Tuesday might have 4x400m intervals, Week 2 Tuesday might have 3x800m intervals, and Week 3 Tuesday might have hill repeats. The intensity, distance, workout types, and recovery periods should all progress and vary throughout the training plan. Incorporate periodization principles with some weeks being higher intensity and others allowing more recovery. NEVER create static, repetitive plans where every Tuesday has the exact same workout.
4. DETAILED FIRST WORKOUT: When creating a new training plan, always describe the FIRST workout in detail within your chat message. Tell the user exactly what they'll be doing for their next workout, not just that it's been created.
5. ASK ABOUT RUNNING TIME: If you don't already know when the user typically runs (morning, afternoon, evening), ask them about their preferred running time. Use this information to provide time-specific guidance.
6. USE TIME PREFERENCES: If you know their preferred running time, occasionally mention it when discussing workouts (e.g., "For tomorrow's afternoon run, you'll be doing...").
7. CRITICAL - FULL WORKOUT DETAILS IN CHAT MESSAGE: ONLY AFTER having a proper initial conversation with the user and understanding their specific needs, you MUST include ALL workout details directly in your chat message text when creating a plan. Never reply with just a brief intro - always list each workout day with its complete details right in the message. For new users, do not create a workout plan until after your second conversation exchange. Format the entire weekly schedule in your message STARTING WITH TOMORROW'S WORKOUT, not Monday. For example, if today is Thursday, start with Friday's workout:

Friday (Tomorrow): [Full workout description with all steps]
Saturday: [Full workout description with all steps]
Sunday: [Full workout description with all steps]
...and so on for each day of the week

For example, when asked for a weekly plan on a Thursday, your response MUST look like:
"Here's your complete week, starting with tomorrow:

Friday (Tomorrow): 30-minute easy run - Start with a 5-minute walking warm-up, then 20 minutes of easy running at conversation pace, followed by a 5-minute walking cool-down.

Saturday: Strength training - 3 sets of: 10 push-ups, 15 bodyweight squats, 20-second plank, with 45 seconds rest between sets.

Sunday: 35-minute moderate run with intervals - 5-minute warm-up walk, 25 minutes of running with 5 x 1-minute faster intervals, 5-minute cool-down walk."

And so on for every day of the week. The workout details in your message MUST match what's in the "workouts" data exactly.
8. SPECIFIC EXERCISE DETAILS: When recommending bodyweight or strength exercises, be extremely specific with exact sets, reps, and rest periods. For example, instead of saying "10 minutes of bodyweight exercises", say "3 sets of: 10 push-ups, 15 bodyweight squats, 20-second plank, with 45 seconds rest between sets". All strength training exercises should be added to the workouts tab as well.
9. FOLLOW-UP QUESTIONS: After the user responds to your first greeting message, follow up with specific questions: ask about their specific preferred running time (e.g., "What exact time do you prefer for your morning runs?"), ask which day they would prefer for their long run (this is crucial for proper training structure), and ask about another training aspect like strength training interest or mileage goals.
10. WORKOUT VARIATION BETWEEN WEEKS: If a user asks for another week of workouts, never give them the exact same workouts as the previous week. Even when following a similar structure, vary the details, distances, intensities, or specific exercises to keep the training stimulating and progressive. When the user is approaching a new week in their training plan, highlight how this week differs from the previous week (e.g., "This week we're increasing your long run distance by 10% and adding some hill repeats to your Thursday workout").

CRITICAL REQUIREMENT: For new users, do NOT include the "workouts" array in your first or second messages - focus on gathering information first. Only include the "workouts" array after you've had a proper conversation with the user. When you do create workouts, ALWAYS ensure every workout mentioned in your message text is also in the workouts array with EXACTLY matching day names and details. If you're uncertain about creating workouts, omit the "workouts" property completely rather than creating incorrect or inconsistent data.`;

    // Build message array with proper type handling
    const typedMessages: ChatCompletionMessageParam[] = [
      { role: "system", content: systemMessage ? `${systemPrompt}\n\n${systemMessage}` : systemPrompt }
    ];

    // Add chat history if available
    if (chatHistory && chatHistory.length > 0) {
      chatHistory.forEach(msg => {
        typedMessages.push({
          role: msg.isUserMessage ? "user" : "assistant",
          content: msg.content
        });
      });
    }

    // Check if user is asking for a weekly plan
    const isAskingForPlan = userMessage.toLowerCase().includes("weekly plan") || 
                           userMessage.toLowerCase().includes("plan for the week") || 
                           userMessage.toLowerCase().includes("week plan") ||
                           userMessage.toLowerCase().includes("running plan");
    
    // Check if user is asking for variation in workouts
    const isAskingForVariation = userMessage.toLowerCase().includes("different workout") || 
                                userMessage.toLowerCase().includes("dynamic") || 
                                userMessage.toLowerCase().includes("diverse") ||
                                userMessage.toLowerCase().includes("variety") ||
                                userMessage.toLowerCase().includes("change up") ||
                                userMessage.toLowerCase().includes("mix it up");
    
    // Add training plan variation reminder
    typedMessages.push({ 
      role: "system", 
      content: "CRITICAL INSTRUCTIONS FOR WORKOUT VARIATION AND PROGRESSION: You MUST create varied and dynamic training plans where workouts evolve week-to-week. Even when general workout types remain the same day-to-day (e.g., Tuesday is always intervals), the specific details should vary each week. For example, Week 1 Tuesday might have 4x400m intervals, while Week 2 Tuesday might have 3x800m intervals, and Week 3 Tuesday might have hill repeats. The intensity, distance, types of intervals, and recovery periods should all progress and vary throughout the training plan. Incorporate periodization principles where some weeks are higher intensity and others allow more recovery. NEVER create static, repetitive plans where every Tuesday is exactly the same workout. This is ABSOLUTELY CRITICAL for effective training and user satisfaction."
    });
    
    // Add extra reminder if asking for a plan
    if (isAskingForPlan || isAskingForVariation) {
      // Check if this is a new conversation (first or second message) or an ongoing one
      const isNewConversation = !chatHistory || chatHistory.length < 3;
      
      if (isNewConversation) {
        typedMessages.push({ 
          role: "system", 
          content: "The user is asking for a workout plan, but this appears to be a new conversation. Ask more questions first to understand their specific needs, preferences, and constraints before creating a full plan. Do not generate a complete workout plan yet - instead, gather more information and suggest you'll create a plan after learning more about them." 
        });
      } else {
        typedMessages.push({ 
          role: "system", 
          content: "IMPORTANT REMINDER: The user is asking for a weekly workout plan. Your response MUST include the COMPLETE details for EVERY workout day of the week directly in your message text, STARTING WITH TOMORROW'S WORKOUT. Always create plans that start with TOMORROW, not Monday. Format each day separately with full details. Provide workouts in chronological order starting from tomorrow. For example, if today is Thursday, start with Friday's workout, then Saturday, Sunday, etc. Make sure your workouts are dynamic and progressive - they should NOT be the same workouts week after week. Vary the intensity, distance, and workout types as the user progresses. ALWAYS ensure there is a workout planned for TOMORROW (unless specifically requested as a rest day). If the user specifically asks to start today, include a workout for today as well. Type as though you can only type a maximum of 200 words per minute to avoid overwhelming the user with too much text at once." 
        });
        
        if (isAskingForVariation) {
          typedMessages.push({ 
            role: "system", 
            content: "The user is specifically asking for more varied and dynamic workouts. Emphasize in your response how you're creating a plan with greater variety. Include different types of runs (tempos, intervals, progression runs, fartleks), varied strength exercises, and different intensities. Avoid repetitive workouts like '30 minute easy run' multiple times per week - instead, make each workout unique with specific instructions and varied elements." 
          });
        }
      }
    }

    // Add the current user message
    typedMessages.push({ role: "user", content: userMessage });

    // Call the OpenAI API
    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: typedMessages,
      response_format: { type: "json_object" },
    });

    const content = response.choices[0].message.content;
    
    // Parse the JSON response
    return JSON.parse(content || '{"message": "I apologize, but I could not generate a response at this time."}');
  } catch (error) {
    console.error("Error getting running coach response:", error);
    return {
      message: "I'm sorry, I encountered an error while processing your request. Please try again later."
    };
  }
}
