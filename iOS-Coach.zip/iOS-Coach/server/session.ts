import session from 'express-session';
import memoryStore from 'memorystore';

// Use memorystore to avoid database session issues
export function createSessionStorage() {
  // Create memory store for sessions
  const MemoryStore = memoryStore(session);
  
  return new MemoryStore({
    checkPeriod: 86400000 // 24 hours
  });
}