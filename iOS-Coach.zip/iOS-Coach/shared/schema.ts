import { pgTable, text, serial, integer, boolean, timestamp, json } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  email: text("email").notNull().unique(),
  password: text("password").notNull(),
  role: text("role").default("user").notNull(), // possible values: "user", "admin"
  pushToken: text("push_token"), // Store device push notification token
  createdAt: timestamp("created_at").defaultNow(),
});

export const runningProfiles = pgTable("running_profiles", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  experience: text("experience").notNull(), // beginner, intermediate, advanced, elite
  mileTimeMinutes: integer("mile_time_minutes").notNull(),
  mileTimeSeconds: integer("mile_time_seconds").notNull(),
  weeklyMileage: integer("weekly_mileage").notNull(),
  trainingGoal: text("training_goal").notNull(), // general_fitness, distance, speed, race
  raceType: text("race_type"), // 5k, 10k, half_marathon, marathon, ultra
  strengthTraining: text("strength_training"), // none, bodyweight, weights
  preferredRunTime: text("preferred_run_time"), // morning, mid_day, evening
  restDays: text("rest_days").array(), // monday, tuesday, wednesday, thursday, friday, saturday, sunday
  createdAt: timestamp("created_at").defaultNow(),
});

export const messages = pgTable("messages", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  content: text("content").notNull(),
  isUserMessage: boolean("is_user_message").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const workouts = pgTable("workouts", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  title: text("title").notNull(),
  description: text("description").notNull(),
  dayOfWeek: text("day_of_week").notNull(), // Monday, Tuesday, etc.
  intensity: text("intensity").notNull(), // Low, Medium, High
  details: json("details").$type<string[]>().notNull(),
  isComplete: boolean("is_complete").default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

export const trainingPlans = pgTable("training_plans", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  title: text("title").notNull(),
  description: text("description").notNull(),
  durationWeeks: integer("duration_weeks").notNull(),
  currentWeek: integer("current_week").default(1),
  createdAt: timestamp("created_at").defaultNow(),
});

export const deviceTokens = pgTable("device_tokens", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  token: text("token").notNull().unique(),
  deviceType: text("device_type").notNull(), // "ios" or "android"
  createdAt: timestamp("created_at").defaultNow(),
});

// Insert schemas
export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true,
}).extend({
  role: z.string().optional(), // Make role optional with string type
});

export const insertRunningProfileSchema = createInsertSchema(runningProfiles).omit({
  id: true,
  createdAt: true,
});

export const insertMessageSchema = createInsertSchema(messages).omit({
  id: true,
  createdAt: true,
});

export const insertWorkoutSchema = createInsertSchema(workouts).omit({
  id: true,
  createdAt: true,
});

export const insertTrainingPlanSchema = createInsertSchema(trainingPlans).omit({
  id: true,
  createdAt: true,
});

export const insertDeviceTokenSchema = createInsertSchema(deviceTokens).omit({
  id: true,
  createdAt: true,
});

// Types
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export type InsertRunningProfile = z.infer<typeof insertRunningProfileSchema>;
export type RunningProfile = typeof runningProfiles.$inferSelect;

export type InsertMessage = z.infer<typeof insertMessageSchema>;
export type Message = typeof messages.$inferSelect;

export type InsertWorkout = z.infer<typeof insertWorkoutSchema>;
export type Workout = typeof workouts.$inferSelect;

export type InsertTrainingPlan = z.infer<typeof insertTrainingPlanSchema>;
export type TrainingPlan = typeof trainingPlans.$inferSelect;

// Login schema
export const loginSchema = z.object({
  email: z.string().email(),
  password: z.string().min(8),
});

// Registration schema with validation
export const registerSchema = insertUserSchema.extend({
  password: z.string().min(8).regex(/.*[0-9].*/).regex(/.*[!@#$%^&*()_+\-=[\]{};':"\\|,.<>/?].*/),
  confirmPassword: z.string(),
}).refine((data) => data.password === data.confirmPassword, {
  message: "Passwords do not match",
  path: ["confirmPassword"],
});

// Chat message schema
export const chatMessageSchema = z.object({
  message: z.string().min(1),
});
