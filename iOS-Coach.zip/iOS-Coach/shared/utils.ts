/**
 * Shared utility functions for the application
 */

/**
 * Returns day names and information about today and tomorrow
 */
export function getDayNames() {
  const daysOfWeek = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
  const today = new Date();
  const todayDayName = daysOfWeek[today.getDay()];
  const tomorrowDayName = daysOfWeek[(today.getDay() + 1) % 7];
  return { daysOfWeek, today, todayDayName, tomorrowDayName };
}