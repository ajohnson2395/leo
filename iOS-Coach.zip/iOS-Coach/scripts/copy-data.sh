#!/bin/bash

# Create necessary directories
mkdir -p dist/server/data
mkdir -p dist/server/data/persistence

# Copy data files
cp -r server/data/coachingPreferences.json dist/server/data/
cp -r server/data/persistence/*.json dist/server/data/persistence/

echo "Data files copied to dist directory"