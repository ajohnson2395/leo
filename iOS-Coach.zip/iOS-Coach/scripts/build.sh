#!/bin/bash

# Run the original build command
vite build && esbuild server/index.ts --platform=node --packages=external --bundle --format=esm --outdir=dist

# Create necessary directories
mkdir -p dist/server/data
mkdir -p dist/server/data/persistence

# Copy data files
cp -r server/data/coachingPreferences.json dist/server/data/
cp -r server/data/persistence/*.json dist/server/data/persistence/

echo "Build completed and data files copied to dist directory"